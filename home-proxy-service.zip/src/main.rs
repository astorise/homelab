
mod proxy;
pub mod homeproxy {
    tonic::include_proto!("homeproxy.v1");
}
use homeproxy::home_proxy_server::{HomeProxy, HomeProxyServer};
use homeproxy::*;
use tokio::net::windows::named_pipe::{ServerOptions};
use tokio_stream::wrappers::ReceiverStream;
use tokio_stream::StreamExt;
use std::sync::{Arc, Mutex};
use anyhow::Result;
use serde::{Serialize, Deserialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
struct Config {
    http: u16,
    https: u16,
    wsl_resolve: String,
    wsl_refresh_secs: u64,
    routes: std::collections::HashMap<String, u16>,
    log_level: String,
}

#[derive(Clone)]
struct ProxyService {
    cfg: Arc<Mutex<Config>>,
}

#[tonic::async_trait]
impl HomeProxy for ProxyService {
    async fn stop_service(&self, _: tonic::Request<Empty>) -> Result<tonic::Response<Acknowledge>, tonic::Status> {
        // trigger stop logic
        Ok(tonic::Response::new(Acknowledge{ ok: true, message: "Stopping".into() }))
    }
    async fn reload_config(&self, _: tonic::Request<Empty>) -> Result<tonic::Response<Acknowledge>, tonic::Status> {
        Ok(tonic::Response::new(Acknowledge{ ok: true, message: "Reloaded".into() }))
    }
    async fn get_status(&self, _: tonic::Request<Empty>) -> Result<tonic::Response<StatusResponse>, tonic::Status> {
        Ok(tonic::Response::new(StatusResponse{ state: "Running".into(), log_level: "info".into() }))
    }
    async fn add_route(&self, req: tonic::Request<AddRouteRequest>) -> Result<tonic::Response<Acknowledge>, tonic::Status> {
        let r = req.into_inner();
        self.cfg.lock().unwrap().routes.insert(r.host, r.port);
        Ok(tonic::Response::new(Acknowledge{ ok: true, message: "Route added".into() }))
    }
    async fn remove_route(&self, req: tonic::Request<RemoveRouteRequest>) -> Result<tonic::Response<Acknowledge>, tonic::Status> {
        let r = req.into_inner();
        self.cfg.lock().unwrap().routes.remove(&r.host);
        Ok(tonic::Response::new(Acknowledge{ ok: true, message: "Route removed".into() }))
    }
    async fn list_routes(&self, _: tonic::Request<Empty>) -> Result<tonic::Response<ListRoutesResponse>, tonic::Status> {
        let routes_map = self.cfg.lock().unwrap().routes.clone();
        let routes_vec = routes_map.into_iter().map(|(h,p)| list_routes_response::Route{ host:h, port:p }).collect();
        Ok(tonic::Response::new(ListRoutesResponse{ routes: routes_vec }))
    }
}

#[tokio::main]
async fn main() -> Result<()> {
    flexi_logger::Logger::try_with_str("info")?.start()?;
    let cfg: Config = serde_yaml::from_str(&std::fs::read_to_string("conf/http.yaml")?)?;
    let service = ProxyService { cfg: Arc::new(Mutex::new(cfg)) };

    let pipe = r"\\.\pipe\home-proxy";
    let incoming = async_stream::stream! {
        loop {
            match ServerOptions::new().create(pipe) {
                Ok(pipe) => yield Ok::<_, std::io::Error>(pipe),
                Err(e) => {
                    eprintln!("Pipe error: {}", e);
                    break;
                }
            }
        }
    };

    tonic::transport::Server::builder()
        .add_service(HomeProxyServer::new(service))
        .serve_with_incoming(incoming)
        .await?;

    Ok(())
}
