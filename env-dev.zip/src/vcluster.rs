use std::process::Command;
use std::error::Error;
use std::str;
use serde::{Deserialize, Serialize};
use serde_yaml;

#[derive(Serialize, Deserialize, Debug)]
struct ClusterConfig {
    apiVersion: String,
    clusters: Vec<Cluster>,
    contexts: Vec<Context>,
    current_context: String,
    kind: String,
    preferences: Preferences,
    users: Vec<User>,
}

#[derive(Serialize, Deserialize, Debug)]
struct Cluster {
    name: String,
    cluster: ClusterDetails,
}

#[derive(Serialize, Deserialize, Debug)]
struct ClusterDetails {
    #[serde(rename = "certificate-authority-data")]
    certificate_authority_data: String,
    server: String,
}

#[derive(Serialize, Deserialize, Debug)]
struct Context {
    name: String,
    context: ContextDetails,
}

#[derive(Serialize, Deserialize, Debug)]
struct ContextDetails {
    cluster: String,
    user: String,
}

#[derive(Serialize, Deserialize, Debug)]
struct Preferences {}

#[derive(Serialize, Deserialize, Debug)]
struct User {
    name: String,
    user: UserDetails,
}

#[derive(Serialize, Deserialize, Debug)]
struct UserDetails {
    token: String,
}

pub(crate) fn install_vcluster(instance_name: &str)->std::result::Result<(), Box<dyn Error>>  {
    Command::new("wsl")
    .arg("-d")
    .arg(instance_name)
    .args([
        "sh",
        "-c",
        format!(
            " wget -O /usr/local/bin/vcluster https://github.com/loft-sh/vcluster/releases/latest/download/vcluster-linux-amd64  && chmod +x /usr/local/bin/vcluster")
        .as_str(),
    ])
    .output()
    .expect("Échec de l'exécution de la commande");
  
    Ok(())
  }
  fn deploy_vcluster(instance_name: &str,vcluster_name: &str)-> Result<(), Box<dyn std::error::Error>>{
    let output = Command::new("wsl")
    .args(&["-d", instance_name, "--", "sh", "-c", &format!(r#"kubectl create namespace {} && echo "
    controlPlane:
      distro:
        k3s:
          enabled: true
          extraArgs:
          - --tls-san {}.k3s.wsl
      statefulSet:
        scheduling:
          podManagementPolicy: OrderedReady "|helm template {} vcluster --repo https://charts.loft.sh -n {} -f - | kubectl apply -f -"#,vcluster_name,vcluster_name,vcluster_name,vcluster_name)])
          .output()
          .expect("Échec de l'exécution de la commande");
        println!("log:{}, err:{}",String::from_utf8_lossy(&output.stdout),String::from_utf8_lossy(&output.stderr));
    Ok(())
    
  }
  
pub(crate) fn deploy_vclusters(instance_name: &str)->std::result::Result<(), Box<dyn Error>>  {
  let vclusters = vec![
    "devops",
    "staging",
    "prod"
];

// Générer les kubeconfigs pour chaque vcluster
for vcluster_name in vclusters {
  deploy_vcluster(instance_name,vcluster_name)?;
}



    
    let commands = vec![
      "kubectl apply -f https://github.com/jetstack/cert-manager/releases/download/v1.14.2/cert-manager.crds.yaml".to_string(),
      "kubectl create namespace cert-manager".to_string(),
      "kubectl apply -f https://github.com/jetstack/cert-manager/releases/download/v1.14.2/cert-manager.yaml".to_string(),
  ];

  
  for command in commands {
  Command::new("wsl")
      .args(&["-d", instance_name, "--", "sh", "-c", &command])
      .status()?;
  }
  
  loop {
  let output =    Command::new("wsl")
  .args(&[
  "-d",
  instance_name,
  "--",
  "sh",
  "-c",r#"echo $(kubectl get pods -n cert-manager -l app.kubernetes.io/component=webhook -o jsonpath="{.items[0].status.containerStatuses[0].ready}")"#]).output()
  .expect("Échec de l'exécution de la commande");
  if String::from_utf8_lossy(&output.stdout).trim().to_string()=="true" {
  break;
  };
  std::thread::sleep(std::time::Duration::from_secs(1));
  }

  let output = Command::new("wsl")
.args(&["-d",
    instance_name,
    "--",
    "sh",
    "-c",
    r#"echo '
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: selfsigning-issuer
spec:
  selfSigned: {}
---
apiVersion: v1
kind: Namespace
metadata:
  name: envoy-ingress
---
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: devops-vcluster-cert
  namespace: envoy-ingress
spec:
  secretName: devops-vcluster-tls
  issuerRef:
    name: selfsigning-issuer
    kind: ClusterIssuer
  dnsNames:
  - "devops.vcluster"
---
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: stagging-vcluster-cert
  namespace: envoy-ingress
spec:
  secretName: stagging-vcluster-tls
  issuerRef:
    name: selfsigning-issuer
    kind: ClusterIssuer
  dnsNames:
  - "stagging.vcluster"
---
apiVersion: cert-manager.io/v1
kind: Certificate
metadata:
  name: prod-vcluster-cert
  namespace: envoy-ingress
spec:
  secretName: prod-vcluster-tls
  issuerRef:
    name: selfsigning-issuer
    kind: ClusterIssuer
  dnsNames:
  - "prod.vcluster"
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: envoy-config
  namespace: envoy-ingress
data:
  envoy.yaml: |
    static_resources:
      listeners:
      - name: listener_0
        address:
          socket_address: { address: 0.0.0.0, port_value: 443 }
        filter_chains:
        - filter_chain_match:
            server_names: ["devops.vcluster"]
          tls_context:
            common_tls_context:
              tls_certificates:
              - certificate_chain: { filename: "/etc/envoy/certs/devops/tls.crt" }
                private_key: { filename: "/etc/envoy/certs/devops/tls.key" }
          filters:
          - name: envoy.filters.network.http_connection_manager
            # Configuration spécifique au vCluster devops
        - filter_chain_match:
            server_names: ["stagging.vcluster"]
          tls_context:
            common_tls_context:
              tls_certificates:
              - certificate_chain: { filename: "/etc/envoy/certs/stagging/tls.crt" }
                private_key: { filename: "/etc/envoy/certs/stagging/tls.key" }
          filters:
          - name: envoy.filters.network.http_connection_manager
            # Configuration spécifique au vCluster stagging
        - filter_chain_match:
            server_names: ["prod.vcluster"]
          tls_context:
            common_tls_context:
              tls_certificates:
              - certificate_chain: { filename: "/etc/envoy/certs/prod/tls.crt" }
                private_key: { filename: "/etc/envoy/certs/prod/tls.key" }
          filters:
          - name: envoy.filters.network.http_connection_manager
            # Configuration spécifique au vCluster prod
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: envoy
  namespace: envoy-ingress
spec:
  replicas: 1
  selector:
    matchLabels:
      app: envoy
  template:
    metadata:
      labels:
        app: envoy
    spec:
      containers:
      - name: envoy
        image: envoyproxy/envoy:v1.29.1
        ports:
        - containerPort: 80
        - containerPort: 443
        volumeMounts:
        - name: devops-cert-volume
          mountPath: "/etc/envoy/certs/devops"
          readOnly: true
        - name: stagging-cert-volume
          mountPath: "/etc/envoy/certs/stagging"
          readOnly: true
        - name: prod-cert-volume
          mountPath: "/etc/envoy/certs/prod"
          readOnly: true
      volumes:
      - name: devops-cert-volume
        secret:
          secretName: devops-vcluster-tls
      - name: stagging-cert-volume
        secret:
          secretName: stagging-vcluster-tls
      - name: prod-cert-volume
        secret:
          secretName: prod-vcluster-tls  
' | kubectl apply -f -"#
])
.output()
    .expect("Échec de l'exécution de la commande");
println!("log:{}, err:{}",String::from_utf8_lossy(&output.stdout),String::from_utf8_lossy(&output.stderr));
  
let vclusters = vec![
  "devops",
  "staging",
  "prod"];
  // Générer les kubeconfigs pour chaque vcluster
  for vcluster_name in vclusters {
   generate_kubeconfig(instance_name,vcluster_name)?;
}

    Ok(())
  }


  
pub(crate) fn generate_kubeconfig(instance_name: &str,vcluster_name: &str) -> Result<(), Box<dyn std::error::Error>> {
  
let output = Command::new("wsl")
.args(&["-d",
    instance_name,
    "--",
    "sh",
    "-c",
    format!(r#"kubectl wait --for=condition=ready pod/{}-0 -n {} --timeout=120s && kubectl exec -i {}-0 -n {} -- cat /root/.kube/config | sed "s|https://localhost|https://{}.vcluster|" | base64 -w 0 | xargs -I {{}} sh -c 'echo -e "apiVersion: v1\nkind: Secret\nmetadata:\n  name: {}-kubeconfig\n  namespace: {}\ndata:\n  kubeconfig: {{}}" | kubectl apply -f -'"#,vcluster_name,vcluster_name,vcluster_name,vcluster_name,vcluster_name,vcluster_name,vcluster_name).as_str()])
    .output()
        .expect("Échec de l'exécution de la commande")
        ;
        println!(r#"kubectl wait --for=condition=ready pod/{}-0 -n {} --timeout=120s && kubectl exec -i {}-0 -n {} -- cat /root/.kube/config | sed "s|https://localhost|https://{}.vcluster|" | base64 -w 0 | xargs -I {{}} sh -c 'echo -e "apiVersion: v1\nkind: Secret\nmetadata:\n  name: {}-kubeconfig\n  namespace: {}\ndata:\n  kubeconfig: {{}}" | kubectl apply -f -'"#,vcluster_name,vcluster_name,vcluster_name,vcluster_name,vcluster_name,vcluster_name,vcluster_name);
        println!("log:{}, err:{}",String::from_utf8_lossy(&output.stdout),String::from_utf8_lossy(&output.stderr));

    Ok(())
}



  fn get_k8s_secret(instance_name: &str, vcluster_name: &str, secret_key: &str) -> String {
    let output = Command::new("wsl")
        .args(&["-d", instance_name, "--", "sh", "-c",
                format!("kubectl get secret vc-{} -n {} -o jsonpath='{{.data.{}}}'", vcluster_name, vcluster_name, secret_key).as_str()])
        .output()
        .expect("Échec de l'exécution de la commande")
        .stdout;

    str::from_utf8(&output).expect("Échec de la conversion de la sortie").trim().to_string()
}