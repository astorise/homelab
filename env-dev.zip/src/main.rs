
use std::error::Error;


mod alpine;
mod k3s;
mod helm;
mod vcluster;
mod minio;
mod tools;
mod gitlab;






//#[tokio::main]
fn main() -> std::result::Result<(), Box<dyn Error>> {
    let instance_k3_name = "k3s";
    alpine::import_alpine(instance_k3_name).expect("Erreur installation Alpine K3S");
    
    k3s::install_k3s(instance_k3_name).expect("Erreur installation K3S");
    helm::install_helm(instance_k3_name).expect("Erreur installation helm");
    vcluster::install_vcluster(instance_k3_name).expect("Erreur installation vcluster");
    vcluster::deploy_vclusters(instance_k3_name).expect("Erreur déploiement vcluster");
    minio::deploy_minio(instance_k3_name).expect("Erreur installation minio");
    gitlab::deploy_gitlab(instance_k3_name).expect("Erreur déploiement gitlab");
    //vcluster::export_kubeconfig_vcluster(instance_k3_name).expect("Erreur export kubeconfig");
    //service::update_minio(instance_name).expect("Erreur update");

    Ok(())
}
